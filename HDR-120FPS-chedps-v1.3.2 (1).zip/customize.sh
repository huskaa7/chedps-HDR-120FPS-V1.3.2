#!/system/bin/sh
# Chedps HDR + 120 FPS Module v1.3.2

ui_print "*******************************"
ui_print " HDR & 120 FPS ! - chedps"
ui_print " Version: v1.3.2"
ui_print "*******************************"

DEVICE_MODEL="$(getprop ro.product.marketname)"
[ -n "$DEVICE_MODEL" ] || DEVICE_MODEL="$(getprop ro.product.model)"
[ -n "$DEVICE_MODEL" ] || DEVICE_MODEL="Unknown device"

DEVICE_BRAND="$(getprop ro.product.manufacturer)"
[ -n "$DEVICE_BRAND" ] || DEVICE_BRAND="$(getprop ro.product.brand)"
ANDROID_VERSION="$(getprop ro.build.version.release)"
[ -n "$ANDROID_VERSION" ] || ANDROID_VERSION="Unknown"

ui_print "Device: ${DEVICE_BRAND} ${DEVICE_MODEL}"
ui_print "Android: ${ANDROID_VERSION}"
ui_print " "
ui_print "Installation finished."
ui_print "Opening Chedps Telegram channel in Chrome..."

# Attempt to open Chrome immediately at the end of installation.
# This works only if Android's app framework is running and Chrome is installed.
am start -a android.intent.action.VIEW \
    -d "https://t.me/chedps1" \
    -p com.android.chrome >/dev/null 2>&1

if [ "$?" -ne 0 ]; then
    ui_print "Chrome could not be opened from this installer environment."
    ui_print "Open this link manually after Android starts:"
    ui_print "https://t.me/chedps1"
fi

ui_print "*******************************"
